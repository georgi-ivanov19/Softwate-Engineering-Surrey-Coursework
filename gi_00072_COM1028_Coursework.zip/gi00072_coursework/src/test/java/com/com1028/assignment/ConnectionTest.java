package com.com1028.assignment;

import static org.junit.Assert.*;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.junit.Test;

public class ConnectionTest {

	//a basic to test that tests the connection to the server
	
	@Test
	public void testConnection() throws SQLException {
		BaseQuery conn = BaseQuery.getInstance();
		Statement s = conn.getConnection().createStatement();
		ResultSet rs = conn.useTable("orders");
		
		assertFalse(conn.getConnection().isClosed());
		assertFalse(s.isClosed());
		assertFalse(rs.isClosed());
		
		BaseQuery.closeConnection(rs, s, conn.getConnection());
		
		assertTrue(conn.getConnection().isClosed());
		assertTrue(s.isClosed());
		assertTrue(rs.isClosed());
	}

}
