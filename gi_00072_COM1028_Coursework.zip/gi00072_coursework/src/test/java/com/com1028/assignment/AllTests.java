package com.com1028.assignment;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ AmountPaidPerCustomerTest.class, ConnectionTest.class, OrdersOver5000Test.class,
		RevenueGeneratedPerSalesRepTest.class })
public class AllTests {

}
