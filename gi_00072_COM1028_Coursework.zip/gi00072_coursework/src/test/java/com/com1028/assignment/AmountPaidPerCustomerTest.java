package com.com1028.assignment;

import static org.junit.Assert.*;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.junit.Test;

public class AmountPaidPerCustomerTest {

	@Test
	public void testReq1() throws SQLException {

		BaseQuery conn = BaseQuery.getInstance();

		/*
		 * used LEFT JOIN to account for customers that have not yet made an order so
		 * they have not paid anything, and I wanted to print all customers despite some
		 * having paid $0.0
		 */
		String query = "SELECT customers.customerNumber, customers.customerName, SUM(payments.amount) AS totalAmountPaid FROM customers LEFT JOIN payments ON customers.customerNumber=payments.customerNumber GROUP BY customers.customerNumber";
		Statement s = conn.getConnection().createStatement();
		ResultSet rs = s.executeQuery(query);
		StringBuilder output = new StringBuilder();
		try {
			while (rs.next()) {
				output.append("(").append(rs.getInt("customerNumber")).append(") ").append(rs.getString("customerName"))
						.append(" has paid a total of $").append(rs.getDouble("totalAmountPaid")).append("\n");
			}
			assertEquals(output.toString(), Customer.listAmountPaidByEachCustomer());
			BaseQuery.closeConnection(rs, s, conn.getConnection());
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			BaseQuery.closeConnection(rs, s, conn.getConnection());
		}
	}
}
