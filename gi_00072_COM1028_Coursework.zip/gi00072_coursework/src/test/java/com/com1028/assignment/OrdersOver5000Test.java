package com.com1028.assignment;

import static org.junit.Assert.*;

import java.sql.ResultSet;
import java.sql.SQLException;

import java.sql.Statement;

import org.junit.Test;

public class OrdersOver5000Test {

	@Test
	public void testOrdersOver5000() throws SQLException {
		BaseQuery conn = BaseQuery.getInstance();
		String query = "SELECT orderNumber, SUM(quantityOrdered*priceEach) AS totalPrice FROM orderdetails GROUP BY orderNumber HAVING totalPrice > 5000";
		Statement s = conn.getConnection().createStatement();
		ResultSet rs = s.executeQuery(query);
		StringBuilder output = new StringBuilder();
		try {
			while (rs.next()) {
				output.append("Order ").append(rs.getInt("orderNumber")).append(" has a value of $")
						.append(rs.getDouble("totalPrice")).append("\n");
			}
			assertEquals(output.toString(), Order.listOrderNumbersForOrdersOver5000());
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			BaseQuery.closeConnection(rs, s, conn.getConnection());
		}

	}
}
