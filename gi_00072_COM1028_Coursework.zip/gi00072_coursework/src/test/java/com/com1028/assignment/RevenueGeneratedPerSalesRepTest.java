package com.com1028.assignment;

import static org.junit.Assert.*;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.junit.Test;

public class RevenueGeneratedPerSalesRepTest {

	@Test
	public void testOutput() throws SQLException {
		BaseQuery conn = BaseQuery.getInstance();
		
		/*
		 * used LEFT JOIN to account for SalesReps that have not generated any revenue, in order to be able to print every single SalesRep
		 */ 
		String query = "SELECT employees.employeeNumber, employees.firstName, employees.lastName, SUM(payments.amount) AS totalGenerated ,employees.jobTitle FROM employees LEFT JOIN customers ON customers.salesRepEmployeeNumber = employees.employeeNumber LEFT JOIN payments ON payments.customerNumber = customers.customerNumber WHERE jobTitle = \"Sales Rep\" GROUP BY employeeNumber";
		Statement s = conn.getConnection().createStatement();
		ResultSet rs = s.executeQuery(query);
		StringBuilder output = new StringBuilder();
		try {
			while (rs.next()) {
				output.append("(").append(rs.getInt("employeeNumber")).append(") ").append(rs.getString("firstName")).append(" ")
						.append(rs.getString("lastName")).append(" has generated a total of $")
						.append(rs.getDouble("totalGenerated")).append(" as a ").append(rs.getString("jobTitle"))
						.append("\n");
			}
			assertEquals(output.toString(), SalesRep.listRevenueGeneratedPerSalesRep());
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			BaseQuery.closeConnection(rs, s, conn.getConnection());
		}
	}
	
	@Test (expected = NullPointerException.class)
	public void testNullPointer()  {
		SalesRep illegal = new SalesRep(123, null, null);
	}
}
