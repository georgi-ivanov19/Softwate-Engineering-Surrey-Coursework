package com.com1028.assignment;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

public class Order {

	private int orderNumber = 0;
	private List<OrderDetails> orderDetails;


	public Order(int orderNumber) {
		this.orderNumber = orderNumber;
		orderDetails = new ArrayList<OrderDetails>();
	}

	private double calculateTotalPrice() {
		double totalPrice = 0.0;
		for (OrderDetails od : orderDetails) {
			totalPrice += od.getPriceEach() * od.getQuantityOrdered();
		}
		return totalPrice;
	}

	//adding the order details to the list of OrderDetails for each individual order
	private void addOrderDetailsToOrder() throws SQLException {
		BaseQuery conn = BaseQuery.getInstance();
		ResultSet orderDetailsTable = conn.useTable("orderDetails");
		try {
			while (orderDetailsTable.next()) {
				if (orderDetailsTable.getInt("orderNumber") == this.orderNumber) {
					orderDetails.add(new OrderDetails(orderDetailsTable.getInt("quantityOrdered"),
							orderDetailsTable.getDouble("priceEach")));
				}
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			BaseQuery.closeConnection(orderDetailsTable, conn.getConnection());
		}
	}

	//building the format of the output for the requirement
	private String orderTotalPrice() throws SQLException {
		DecimalFormat df = new DecimalFormat("#.0#");
		return "Order " + this.orderNumber + " has a value of $" + df.format(this.calculateTotalPrice());
	}

	//making a list of all orders, then adding the details and printing only the ones with value > 5000 as in the requirement
	public static String listOrderNumbersForOrdersOver5000() throws SQLException {
		BaseQuery conn = BaseQuery.getInstance();
		ResultSet ordersTable = conn.useTable("orders");
		List<Order> orders = new ArrayList<Order>();
		StringBuilder ordersOver5000 = new StringBuilder();
		
		try {		
			while (ordersTable.next()) {
				orders.add(new Order(ordersTable.getInt("orderNumber")));
			}
			ordersTable.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			BaseQuery.closeConnection(ordersTable, conn.getConnection());
		}
		for (Order order : orders) {
			order.addOrderDetailsToOrder();
			if (order.calculateTotalPrice() > 5000) {
				ordersOver5000.append(order.orderTotalPrice()).append("\n");
			}
		}
		return ordersOver5000.toString();
	}
}
