package com.com1028.assignment;

public class OrderDetails {
	private int quantityOrdered = 0;
	private double priceEach = 0.0;

	public OrderDetails(int quantityOrdered, double priceEach) throws IllegalArgumentException {
		if(quantityOrdered <= 0 || priceEach <= 0) {
			throw new IllegalArgumentException("Quantity ordered and price cannot be 0 or less!");
		}
		this.quantityOrdered = quantityOrdered;
		this.priceEach = priceEach;
	}

	public int getQuantityOrdered() {
		return quantityOrdered;
	}

	public double getPriceEach() {
		return priceEach;
	}

}