package com.com1028.assignment;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

public class Customer {

	private int customerNumber = 0;
	private String customerName = null;
	private List<Double> payments = null;

	public Customer(int customerNumber, String customerName) throws NullPointerException {
		if(customerName == null) {
			throw new NullPointerException("Customer's name cannot be null!");
		}
		this.customerName = customerName;
		this.customerNumber = customerNumber;
		payments = new ArrayList<Double>();
	}

	private void addPayment(Double payment) throws IllegalArgumentException {
		if (payment <= 0) {
			throw new IllegalArgumentException("Payment cannot be 0 or less");
		}
		this.payments.add(payment);
	}

	private void addPayments() throws SQLException {
		BaseQuery conn = BaseQuery.getInstance();
		ResultSet paymentsTable = conn.useTable("payments");
		try {

			while (paymentsTable.next()) {
				if (paymentsTable.getInt("customerNumber") == this.customerNumber) {
					this.addPayment(paymentsTable.getDouble("amount"));
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			BaseQuery.closeConnection(paymentsTable, conn.getConnection());
		}
	}

	protected double calculateAmountPaidPerCustomer() throws SQLException {
		this.addPayments();
		double total = 0.0;
		for (Double payment : this.payments) {
			total += payment;
		}
		return total;
	}

	public static String listAmountPaidByEachCustomer() throws SQLException {
		BaseQuery conn = BaseQuery.getInstance();
		List<Customer> customers = new ArrayList<Customer>();
		StringBuilder output = new StringBuilder();
		ResultSet customersTable = conn.useTable("customers");
		try {
			while (customersTable.next()) {
				customers.add(new Customer(customersTable.getInt("customerNumber"),
						customersTable.getString("customerName")));
			}
			customersTable.close();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			BaseQuery.closeConnection(customersTable, conn.getConnection());
		}
		for (Customer c : customers) {
			output.append(c.amountPaidByCustomer()).append("\n");
		}
		return output.toString();
	}

	// building the format of the output for the requirement
	private String amountPaidByCustomer() throws SQLException {
		DecimalFormat df = new DecimalFormat("#0.0#");
		return "(" + this.customerNumber + ") " + this.customerName + " has paid a total of $"
				+ df.format(this.calculateAmountPaidPerCustomer());
	}

}
