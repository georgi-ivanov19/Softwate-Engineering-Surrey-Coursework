package com.com1028.assignment;

import java.sql.SQLException;

public class Main {

	public static void main(String[] args) throws SQLException {

		System.out.println("Requirement #1");
		System.out.println(Order.listOrderNumbersForOrdersOver5000());
		System.out.println();
		System.out.println();
		System.out.println("Requirement #2");
		System.out.println(Customer.listAmountPaidByEachCustomer());
		System.out.println();
		System.out.println();
		System.out.println("Requirement #3");
		System.out.println(SalesRep.listRevenueGeneratedPerSalesRep());
	}
}
