package com.com1028.assignment;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

public class SalesRep {
	private int employeeNumber = 0;
	private String firstName = null;
	private String lastName = null;
	List<Customer> servedCustomers = null;

	public SalesRep(int employeeNumber, String firstName, String lastName) throws NullPointerException {
		if(firstName == null || lastName == null) {
			throw new NullPointerException("Employee names cannot be left null");
		}
		this.employeeNumber = employeeNumber;
		this.lastName = lastName;
		this.firstName = firstName;
		servedCustomers = new ArrayList<Customer>();
	}

	private void addCustomer(Customer customer) {
		this.servedCustomers.add(customer);
	}

	//going through all the customers matching them to the SalesRep that serves them and adding them to the list of Customers of that SalesRep
	private void addAllCustomers() throws SQLException {
		BaseQuery conn = BaseQuery.getInstance();
		ResultSet customersTable = conn.useTable("customers");
		try {
			while (customersTable.next()) {
				if (customersTable.getInt("salesRepEmployeeNumber") == this.employeeNumber) {
					this.addCustomer(new Customer(customersTable.getInt("customerNumber"),
							customersTable.getString("customerName")));
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			BaseQuery.closeConnection(customersTable, conn.getConnection());
		}
	}

	/*
	 * adding all the customers to the list of the SalesRep that serves them and
	 * then calculating the revenue of the SalesRep using the method from the class
	 * Customer
	 */
	private double calculateGeneratedRevenue() throws SQLException {

		this.addAllCustomers();
		double totalRevenue = 0.0;
		for (Customer c : this.servedCustomers) {
			totalRevenue += c.calculateAmountPaidPerCustomer();
		}

		return totalRevenue;
	}

	/*
	 * going through all the SalesReps, calculating the revenue for each one and
	 * appending it to the StringBuilder that is used for the output
	 */
	public static String listRevenueGeneratedPerSalesRep() throws SQLException {
		BaseQuery conn = BaseQuery.getInstance();
		List<SalesRep> salesReps = new ArrayList<SalesRep>();
		ResultSet employeesTable = conn.useTable("employees");
		StringBuilder output = new StringBuilder();
		try {
			while (employeesTable.next()) {
				if (employeesTable.getString("jobTitle").matches("Sales Rep")) {
					SalesRep temp = new SalesRep(employeesTable.getInt("employeeNumber"),
							employeesTable.getString("firstName"), employeesTable.getString("lastName"));
					salesReps.add(temp);
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			BaseQuery.closeConnection(employeesTable, conn.getConnection());
		}

		for (SalesRep sr : salesReps) {
			output.append(sr.generatedRevenue()).append("\n");
		}
		return output.toString();
	}

	// building the format of the output for the requirement
	private String generatedRevenue() throws SQLException {
		DecimalFormat df = new DecimalFormat("#0.0#");
		return "(" + this.employeeNumber + ") " + this.firstName + " " + this.lastName + " has generated a total of $"
				+ df.format(this.calculateGeneratedRevenue()) + " as a Sales Rep";
	}
}
