package com.com1028.assignment;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class BaseQuery {
	private static BaseQuery instance = null;
	private Connection connection = null;
	private Statement statement = null;
	private ResultSet rs = null;
	private final String username = "root";
	private final String password = "";
	private final String db = "jdbc:mysql://localhost:3306/classicmodels?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC&verifyServerCertificate=false&useSSL=false";

	public BaseQuery() {
		try {
			DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
			connection = DriverManager.getConnection(db, username, password);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	protected ResultSet useTable(String tableName) throws SQLException {
		String query = "select * from " + tableName;
		statement = connection.createStatement();
		rs = statement.executeQuery(query);
		return rs;
	}

	public Connection getConnection() {
		return connection;
	}

	//did this method because my program was starting to have bugs because of too many connections
	public static BaseQuery getInstance() throws SQLException {
		if (instance == null) {
			instance = new BaseQuery();
		} else if (instance.getConnection().isClosed()) {
			instance = new BaseQuery();
		}
		return instance;
	}

	//did these methods just to make the closure of my connection easier 
	public static void closeConnection(ResultSet rs, Statement s, Connection conn) {
		try {
			rs.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			s.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public static void closeConnection(ResultSet rs, Connection conn) {
		try {
			rs.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
